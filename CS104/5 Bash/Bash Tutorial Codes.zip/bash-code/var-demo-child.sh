#!/bin/bash

echo "X is $X, Y is $Y"

